<?php

/*

 * this is the controller php file posible passed values of $action and $category_id 
 * 1) None - then this the index page so show the default category category (categoryID=1)
 * 2) POST input ->
 * 3) GET input

 *  */

//need the following files to connect to DB and to make fuctions available
require("../model/database.php");
require("../model/members_db.php");
require("../model/contact_db.php");
require("../model/blog_db.php");
require("../model/comment_db.php");
require("../model/Users.php");
require("../model/Blog.php");
require("../model/Comment.php");

session_start();
$action = filter_input(INPUT_POST, 'action');
if ($action == NULL)
{
    $action = filter_input(INPUT_GET, 'action');
    if ($action == NULL)
    {
        $action = 'show_home_page';
    }
}
if ($action == "show_home_page")
{
    $blogs = get_all_blogs();


    include("../view/home.php");
} else if ($action == "show_single_page")
{
    $blogID = filter_input(INPUT_GET, "blogID");

    $blog = get_blog_by_id($blogID);
    $comments = get_comment_by_blog_id($blogID);

    include('../view/single_page.php');
} else if ($action == 'show_Login')
{
    if (isset($_SESSION['memID']))
    {
        header('Location: .?action=show_home_page');
    } else
    {

        include( '../view/login.php');
    }
} else if ($action == "show_sign_in")
{
    if (isset($_SESSION['memID']))
    {
        header('Location: .?action=show_home_page');
    } else
    {

        include '../view/sign_up.php';
    }
} else if ($action == 'create_member')
{
    $user = new Users(null, null, null, null, null, null);
    
    $target_dir = "../DBimages/";

    $target_file = $target_dir . basename($_FILES["fileToUpload"]["name"]);
    $uploadOk = 1;
    $imageFileType = pathinfo($target_file, PATHINFO_EXTENSION);

    $f_name = filter_input(INPUT_POST, 'first-name', FILTER_SANITIZE_STRING);
    $l_name = filter_input(INPUT_POST, 'last-name', FILTER_SANITIZE_STRING);
    $dob = filter_input(INPUT_POST, 'date');
    $email = filter_input(INPUT_POST, 'email', FILTER_SANITIZE_EMAIL);
    $username = filter_input(INPUT_POST, 'username', FILTER_SANITIZE_STRING);
    $password = filter_input(INPUT_POST, 'password');
    $password_hash = md5($password);

    move_uploaded_file($_FILES["fileToUpload"]["tmp_name"], $target_file);
    $user->fname = $f_name;
    $user->lname = $l_name;
    $user->dob = $dob;
    $user->email = $email;
    $user->username = $username;
    $user->password = $password_hash;
          
    $regex = '/^[a-zA-Z0-9_.-]+@[a-zA-Z0-9-]+.[a-zA-Z0-9-.]+$/';
    if (preg_match($regex, $email)) {
        register_member($user->fname, $user->lname, $user->dob, $user->email, $user->username, $user->password, $target_file);
        header('Location: .?action=show_Login');
    } else {
        echo "Email number is bad!";
    }
} else if ($action == 'login_member')
{
    $username = filter_input(INPUT_POST, 'username');
    $password = filter_input(INPUT_POST, 'password');
    $password_hash = md5($password);
    $memID = member_login($username, $password_hash);
    $name = get_member_name_by_ID($memID);
    $ifAdmin = check_member_for_admin($memID);
    if ($memID == NULL)
    {
        $_POST['error'] = TRUE;
        header('Location: .?action=show_Login');
    } else
    {
        $_SESSION['username'] = $name;
        $_SESSION['memID'] = $memID;
        $_SESSION['ifAdmin'] = $ifAdmin;
        header('Location: .?action=show_home_page');
    }
} else if ($action == 'logout')
{
    $_SESSION = array();
    session_destroy();
    header('Location: .?action=show_home_page');
} else if ($action == "add_blog")
{
    if (isset($_SESSION['memID']))
    {
        $blog = new Blog(null, null, null, null);

        $target_dir = "../DBimages/";

        $target_file = $target_dir . basename($_FILES["fileToUpload"]["name"]);
        $uploadOk = 1;
        $imageFileType = pathinfo($target_file, PATHINFO_EXTENSION);


        $title = filter_input(INPUT_POST, 'title', FILTER_SANITIZE_STRING);
        $description = filter_input(INPUT_POST, 'description', FILTER_SANITIZE_STRING);
        $tags = filter_input(INPUT_POST, 'tags', FILTER_SANITIZE_STRING);
        $memID = $_SESSION['memID'];

        move_uploaded_file($_FILES["fileToUpload"]["tmp_name"], $target_file);
        $blog->title = $title;
        $blog->description = $description;
        $blog->tags = $tags;
        $blog->memID = $memID;
        
        add_blog($target_file, $blog->title, $blog->description, $blog->tags, $blog->memID );

        header('Location: .?action=show_home_page');
    } else
    {
        include( '../view/login.php');
    }
} else if ($action == 'add_comment')
{

    if (isset($_SESSION['memID']))
    {
        $comment = new Comment(null, null, null);
        
        $comment1 = filter_input(INPUT_POST, 'comment', FILTER_SANITIZE_STRING);
        $blogID = filter_input(INPUT_POST, 'blogID');
        $memID = $_SESSION['memID'];
        
        $comment->comment = $comment1;
        $comment->blogID = $blogID;
        $comment->memID = $memID;
        
        add_comment($comment->comment, $comment->blogID, $comment->memID);

        header('Location: .?action=show_single_page&blogID=' . $blogID);
    } else
    {
        include( '../view/login.php');
    }
} else if ($action == 'contact_post')
{
    $name = filter_input(INPUT_POST, 'name', FILTER_SANITIZE_STRING);
    $email = filter_input(INPUT_POST, 'email', FILTER_SANITIZE_EMAIL);
    $subject = filter_input(INPUT_POST, 'subject', FILTER_SANITIZE_STRING);
    $message = filter_input(INPUT_POST, 'message', FILTER_SANITIZE_STRING);
    register_contact($name, $email, $subject, $message);

    $_SESSION['contactSubmit'] = "1";
    header('Location:../view/contact.php');
}
