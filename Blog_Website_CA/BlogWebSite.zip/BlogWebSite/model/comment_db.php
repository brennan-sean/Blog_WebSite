<?php
function add_comment($comment,$blogID, $memID) {
    global $db;

    $query = "INSERT INTO comments(comment, blogID, memID) VALUES(:comment, :blogID, :memID)";
    $statement = $db->prepare($query);
    $statement->bindValue(":comment", $comment);
    $statement->bindValue(":blogID", $blogID);
    $statement->bindValue(":memID", $memID);

    try {
        $statement->execute();
    } catch (Exception $ex) {
        header("Location: ../view/error.php?msg=" . $ex->getMessage());
        exit();
    }
    $statement->closeCursor();
}

function get_comment_by_blog_id($blogID){
    global $db;
    
    $query = "Select * FROM comments,members WHERE comments.blogID = :blogID and members.memID = comments.memID";
    $statement = $db->prepare($query);
    $statement->bindValue(":blogID", $blogID);
    try {
        $statement->execute();
    } catch (Exception $ex) {
        header("location:../view/error.php?msg=" . $ex->getMessage());
        exit();
    }
    
    $blog = $statement->fetchAll();
    $statement->closeCursor();
    
    return $blog;
}
