<?php

function add_blog($imagePath, $title, $description, $tags, $memID) {
    global $db;
    
    $query = "INSERT INTO blog(imagePath, title, description, tags, memID)"
            . " values (:imagePath, :title, :description, :tags, :memID)";
    $statement = $db->prepare($query);    
    $statement->bindValue(":imagePath", $imagePath);
    $statement->bindValue(":title", $title);
    $statement->bindValue(":description", $description);
    $statement->bindValue(":tags", $tags);
    $statement->bindValue(":memID", $memID);
    try {
        $statement->execute();
    } catch (Exception $ex) {
        //redirect to an error page passing the error message
        header("location:../view/error.php?msg=" . $ex->getMessage());
        exit();
    }
    
    $statement->closeCursor();
}

function get_all_blogs(){
    global $db;
    
    $query = "Select * FROM blog";
    $statement = $db->prepare($query);
    try {
        $statement->execute();
    } catch (Exception $ex) {
        header("location:../view/error.php?msg=" . $ex->getMessage());
        exit();
    }
    
    $blog = $statement->fetchAll();
    $statement->closeCursor();
    
    return $blog;
}

function get_blog_by_id($blogID){
    global $db;
    
    $query = "Select * FROM blog WHERE blogID = :blogID";
    $statement = $db->prepare($query);
    $statement->bindValue(":blogID", $blogID);
    try {
        $statement->execute();
    } catch (Exception $ex) {
        header("location:../view/error.php?msg=" . $ex->getMessage());
        exit();
    }
    
    $blog = $statement->fetch();
    $statement->closeCursor();
    return $blog;
}
