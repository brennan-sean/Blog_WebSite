<?php
function register_contact($name, $email, $subject, $message) {
    global $db;

    $query = "INSERT INTO contact(name, email, subject, message) VALUES(:name, :email, :subject, :message)";
    $statement = $db->prepare($query);
    $statement->bindValue(":name", $name);
    $statement->bindValue(":email", $email);
    $statement->bindValue(":subject", $subject);
    $statement->bindValue(":message", $message);
    try {
        $statement->execute();
    } catch (Exception $ex) {
        header("Location: ../view/error.php?msg=" . $ex->getMessage());
        exit();
    }
    $statement->closeCursor();
    
}