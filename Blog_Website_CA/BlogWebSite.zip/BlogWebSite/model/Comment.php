<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
class Comment{

public $comment;
public $blogID;
public $memID;

function __construct($comment, $blogID, $memID)
{
    $this->comment = $comment;
    $this->blogID = $blogID;
    $this->memID = $memID;
}
function getComment()
{
    return $this->comment;
}

function getBlogID()
{
    return $this->blogID;
}

function getMemID()
{
    return $this->memID;
}

function setComment($comment)
{
    $this->comment = $comment;
}

function setBlogID($blogID)
{
    $this->blogID = $blogID;
}

function setMemID($memID)
{
    $this->memID = $memID;
}




}