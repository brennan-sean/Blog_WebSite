<?php

class Blog {

public $title;
public $description;
public $tags;
public $memID;

function __construct($title, $description, $tags, $memID)
{
    $this->title = $title;
    $this->description = $description;
    $this->tags = $tags;
    $this->memID = $memID;
}
function getTitle()
{
    return $this->title;
}

function getDescription()
{
    return $this->description;
}

function getTags()
{
    return $this->tags;
}

function getMemID()
{
    return $this->memID;
}

function setTitle($title)
{
    $this->title = $title;
}

function setDescription($description)
{
    $this->description = $description;
}

function setTags($tags)
{
    $this->tags = $tags;
}

function setMemID($memID)
{
    $this->memID = $memID;
}

}
