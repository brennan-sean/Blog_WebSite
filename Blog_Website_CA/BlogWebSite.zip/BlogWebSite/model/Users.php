<?php

class Users {
    public $fname;
    public $lname;
    public $dob;
    public $email;
    public $username;
    public $password;
    
    function __construct($fname, $lname, $dob, $email, $username, $password)
    {
        $this->fname = $fname;
        $this->lname = $lname;
        $this->dob = $dob;
        $this->email = $email;
        $this->username = $username;
        $this->password = $password;
        
    }
    function getFname()
    {
        return $this->fname;
    }

    function getLname()
    {
        return $this->lname;
    }

    function getDob()
    {
        return $this->dob;
    }

    function getEmail()
    {
        return $this->email;
    }

    function getUsername()
    {
        return $this->username;
    }
    
    function getPassword()
    {
        return $this->password;
    }

    
    function setFname($fname)
    {
        $this->fname = $fname;
    }

    function setLname($lname)
    {
        $this->lname = $lname;
    }

    function setDob($dob)
    {
        $this->dob = $dob;
    }

    function setEmail($email)
    {
        $this->email = $email;
    }

    function setUsername($username)
    {
        $this->username = $username;
    }

    function setPassword($password)
    {
        $this->password = $password;
    }

}
