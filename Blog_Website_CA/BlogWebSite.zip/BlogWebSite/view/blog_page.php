
<?php
include ("header.php");
?>

</script>-->
<form action="../controller/" method="post" enctype="multipart/form-data">
    <input type="hidden" name="action" value="add_blog"/>
    <div class="content">
        <div class="wrap">
            <div class="single-page">
                <div class="single-page-artical">
                    <div class="artical-content">

                            <input type="file" name="fileToUpload">

                            <input name="userid" type="hidden" id="userid" value="">
                            <h3>Add Title</h3>
                            <div id="titlediv">
                                <input name="title" id=title type="text">
                            </div>
                            <br>
                            <h4>Add Description</h4>
                            <div id="textdiv">
                                <textarea name="description" id="text" rows="4" cols="50"></textarea>
                            </div>
                            <br>

                            <h4>Add Tags</h4>
                            <div id="textdiv">
                                <input name="tags" id="text">
                            </div>
                            <br>

                            <input type='submit' id="submit" value='Submit'>

                    </div>
                </div>
            </div>
        </div>
    </div>
</form>

<script>

</script>

</body>
</html>
