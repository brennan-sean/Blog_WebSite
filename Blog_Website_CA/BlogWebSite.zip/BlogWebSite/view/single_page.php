<?php
include ("header.php");
?>


<!---start-content---->
<div class="content">
    <div class="wrap">
        <div class="single-page">
            <div class="single-page-artical">
                <div class="artical-content">


                        <img src="<?php echo $blog['imagePath'] ?>"  title="banner1">
                        <h3><a href="#"><?php echo $blog['title'] ?></a></h3>
                        <br>
                        <span><a href="#"><label> </label><?php echo $blog['tags'] ?></a></span>
                        <p><?php echo $blog['description']?></p> 
                </div>


                <div class="artical-links">
                    <ul>
                        <li><img src="../images/blog-icon2.png" title="Admin"><span id="userName"> <?php echo get_member_name_by_ID($blog['memID']) ?></span></a></li>
                        <li><img src="../images/blog-icon3.png" title="Time"><span id="time"><?php echo $blog['create_time'] ?></span></a></li>
                    </ul>
                </div>
                <div class="share-artical">
                    <ul>
                        <li><a href="https://www.facebook.com/"><img src="../images/facebooks.png" title="facebook">Facebook</a></li>
                        <li><a href="https://twitter.com/?lang=en"><img src="../images/twiter.png" title="Twitter">Twiter</a></li>
                        <li><a href="https://plus.google.com/"><img src="../images/google+.png" title="google+">Google+</a></li>
                        <li><a href="https://www.rss.com/"><img src="../images/rss.png" title="rss">Rss</a></li>
                    </ul>
                </div>
                <div class="clear"> </div>
            </div>
            <!---start-comments-section--->
            <div class="comment-section">
                <div class="grids_of_2">
                    <h2>Comments</h2>
                    <?php
                        foreach ($comments as $comment) :
                    ?>
                    
                    <div class="grid1_of_2">
                        <div class="grid_img">
                            <a href=""><img src="<?php echo get_member_image_by_ID($comment['memID']) ?>" class="icon_pic" alt=""></a>
                        </div>
                        
                        <div class="grid_text">
                            <h4 class="style1 list"><a href="#"><?php echo $comment['fname'] ?></a></h4>
                            <h3 class="style"><?php echo $comment['createTime'] ?></h3>
                            <p class="para top"><?php echo $comment['comment'] ?></p>
                        </div>
                        <div class="clear"></div>
                    </div>
                    <?php
                        endforeach;
                    ?>
                    
                    </div>								
                    <div class="artical-commentbox">
                        <h2>Leave a Comment</h2>
                        <div class="table-form">
                            <form action="../controller/" method="post" name="post_comment">
                                <input type="hidden" name="action" value="add_comment"> 
                                <input type="hidden" name="blogID" value="<?php echo $blogID; ?>">
                                <div>
                                    <label>Your Comment<span>*</span></label>
                                    <textarea name="comment"></textarea>	
                                </div>
                                <input type="submit" value="submit">
                            </form>
                            
                        </div>
                        <div class="clear"> </div>
                    </div>			
                </div>
            </div>
            <!---//End-comments-section--->
        </div>
    </div>
</div>

<!---//End-wrap---->
</body>
</html>


