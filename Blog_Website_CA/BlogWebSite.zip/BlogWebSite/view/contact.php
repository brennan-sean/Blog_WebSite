<?php
include ("header.php");
?>

<!---start-content---->
<div class="content">
    <div class="wrap">
        <div class="contact-info">
            <div class="map">
                <iframe width="100%" height="400" frameborder="0" scrolling="no" marginheight="0" marginwidth="0" src="https://maps.google.co.in/maps?f=q&amp;source=s_q&amp;hl=en&amp;geocode=&amp;q=DKIT,+Dundalk,+Ireland&amp;aq=4&amp;oq=light&amp;sll=53.9847126,-6.3888183&amp;sspn=0.04941,0.104628&amp;ie=UTF8&amp;hq=&amp;hnear=DKIT,+Dundalk,+Louth,+Ireland&amp;t=m&amp;z=14&amp;ll=53.9847126,-6.3888183&amp;output=embed"></iframe><br><small><a href="https://maps.google.co.in/maps?f=q&amp;source=s_q&amp;hl=en&amp;geocode=&amp;q=DKIT,+Dundalk,+Ireland&amp;aq=4&amp;oq=light&amp;sll=53.9847126,-6.3888183&amp;sspn=0.04941,0.104628&amp;ie=UTF8&amp;hq=&amp;hnear=DKIT,+Dundalk,+Louth,+Ireland&amp;t=m&amp;z=14&amp;ll=53.9847126,-6.3888183&amp;output=embed" style="color:#666;text-align:left;font-size:12px"></a></small>
            </div>
            <div class="contact-grids">
                <div class="col_1_of_bottom span_1_of_first1">
                    <h5>Address</h5>
                    <ul class="list3">
                        <li>
                            <img src="../images/home.png" alt="">
                            <div class="extra-wrap">
                                <p>Dkit,<br>Dundalk,<br>Co.Louth.</p>
                            </div>
                        </li>
                    </ul>
                </div>
                <div class="col_1_of_bottom span_1_of_first1">
                    <h5>Phones</h5>
                    <ul class="list3">
                        <li>
                            <img src="../images/phone.png" alt="">
                            <div class="extra-wrap">
                                <p><span>Telephone:</span>+(042) 9355555</p>
                            </div>
                            <img src="../images/fax.png" alt="">
                            <div class="extra-wrap">
                                <p><span>FAX:</span>+(042) 9379295</p>
                            </div>
                        </li>
                    </ul>
                </div>
                <div class="col_1_of_bottom span_1_of_first1">
                    <h5>Email</h5>
                    <ul class="list3">
                        <li>
                            <img src="../images/email.png" alt="">
                            <div class="extra-wrap">
                                <p><span class="mail"><a href="mailto:yoursite.com">info@sunrise.ie</a></span></p>
                            </div>
                        </li>
                    </ul>
                </div>
                <div class="clear"></div>
            </div>
            <form action="../controller/" method="post">
                <div class="contact-form">
                    <input type="hidden" name="action" value="contact_post">

                    <div class="contact-to">
                        <input type="text" class="text" name="name" placeholder="Name..." required>
                        <input type="text" class="text" name="email" placeholder="Email..." required>
                        <input type="text" class="text" name="subject" placeholder="Subject..." required>
                    </div>

                    <div class="text2">
                            
                        <textarea type="text" name="message"  placeholder="<?php
                        if (isset($_SESSION['contactSubmit']) && $_SESSION['contactSubmit'] == "1")
                        {
                            $_SESSION['contactSumbit'] = "0";
                            echo "Thank you for your message we will get back to your shortly with a reply.";
                        } else
                        {
                            echo "Message...";
                        }
                        ?>" required></textarea>
                    </div>
                    <span><input type="submit" id="submit" value="Continue">  </span>
                    <div class="clear"></div>

                </div>
            </form>
        </div>
    </div>
</div>
<!----start-footer--->
<div class="footer">

</div>
<!----//End-footer--->
<!---//End-wrap---->
</body>
</html>

