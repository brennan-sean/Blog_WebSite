<?php
if (session_id() == '')
{
    session_start();
}
require_once('../model/members_db.php');
?>
<html>
    <head>
        <title>Pinball Website Template | Home :: w3layouts</title>
        <link href="../css/style.css" rel='stylesheet' type='text/css' />
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="shortcut icon" type="image/x-icon" href="images/fav-icon.png" />
        <script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
        <!----webfonts---->
        <link href='http://fonts.googleapis.com/css?family=Open+Sans:400,300,600,700,800' rel='stylesheet' type='text/css'>
        <!----//webfonts---->
        <!-- Global CSS for the page and tiles -->
        <link rel="stylesheet" href="../css/main.css">
        <!-- //Global CSS for the page and tiles -->
        <!---start-click-drop-down-menu----->
        <script src="../js/jquery.min.js"></script>
        <script src="../js/search.js"></script>
        <!----start-dropdown--->
        <script type="text/javascript">
            var $ = jQuery.noConflict();
            $(function () {
                $('#activator').click(function () {
                    $('#box').animate({'top': '0px'}, 500);
                });
                $('#boxclose').click(function () {
                    $('#box').animate({'top': '-700px'}, 500);
                });
            });
            $(document).ready(function () {
                //Hide (Collapse) the toggle containers on load
                $(".toggle_container").hide();
                //Switch the "Open" and "Close" state per click then slide up/down (depending on open/close state)
                $(".trigger").click(function () {
                    $(this).toggleClass("active").next().slideToggle("slow");
                    return false; //Prevent the browser jump to the link anchor
                });

            });
        </script>
    </head>
    <body>
        <!---start-wrap---->
        <!---start-header---->
        <div class="header">
            <div class="wrap">
                <div class="logo">                      
                    <a href="../controller/?action=show_home_page"><img src="../images/logo2.png" title="sunrise" /></a>
                </div>
                <div class="nav-icon">
                    <a href="#" class="right_bt" id="activator"><span> </span> </a>
                </div>
                <div class="box" id="box">
                    <div class="box_content">        					                         
                        <div class="box_content_center">
                            <div class="form_content">
                                <div class="menu_box_list">
                                    <ul>
                                        <li><a href="../controller/?action=show_home_page"><span>Home</span></a></li>
                                        <li><a href="../view/blog_page.php"><span>Blog</span></a></li>
                                        <li><a href="../view/contact.php"><span>Contact</span></a></li>
                                        <?php
                                        if (!isset($_SESSION['memID']))
                                        {
                                            echo "<li><a href = '../controller/?action=show_sign_in'>Sign Up</a></li></ul>";
                                        } 
                                        ?>
                                        <div class="clear"> </div>
                                    </ul>
                                </div>
                                <a class="boxclose" id="boxclose"> <span> </span></a>
                            </div>                                  
                        </div> 	
                    </div> 
                </div>       	  
                <div class="top-searchbar">
                    <form>
                        <input type="text" onkeyup="filter(this)"/>
                    </form>
                </div>
                <div class="userinfo">
                    <div class="user">
                        <ul>
                            <?php
                            if (isset($_SESSION['memID']))
                            {
                                echo "<li><a href='../controller/?action=logout'><img src='" . get_member_image_by_ID($_SESSION['memID']) . "' class='icon_pic' title='user-name'/><span>Logout</span></a></li>";
                            } else
                            {
                                echo "<li><a href='../controller/?action=show_Login'><span id='login'>Login</span></a></li>";
                            }
                            ?>
                        </ul>
                    </div>
                </div>
                <div class="clear"> </div>
            </div>
        </div>
