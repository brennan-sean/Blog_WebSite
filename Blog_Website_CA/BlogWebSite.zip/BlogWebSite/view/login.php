
<link href="http://netdna.bootstrapcdn.com/font-awesome/4.0.3/css/font-awesome.css" rel="stylesheet">
<link href="../css/signup.css" rel="stylesheet" type="text/css"/>
<?php
include ("header.php");
?>

<header class="ccheader">
    <h1>Please Login</h1>	
</header>
<div class="wrapper">
    <form action="." method="post" id="loginform" class="ccform" >
        <input type="hidden" name="action" value="login_member">   
        
        <div class="ccfield-prepend">
            <span class="ccform-addon"><i id='firsticon' class="fa fa-user fa-2x"></i></span>
            <input id="memberUsername" name="username" class="ccformfield" type="text" placeholder="Username" required>
        </div>
        <div class="ccfield-prepend">
            <span class="ccform-addon"><i class="fa fa-star fa-2x"></i></span>
            <input id="memberPassword" name="password" class="ccformfield" type="password" placeholder="Password" required>
        </div>
        <div class="ccfield-prepend">
            <input class="ccbtn" type="submit" name="submit" id="submit" value="Login">
        </div>
    </form>
</div>   
</body>
</html>