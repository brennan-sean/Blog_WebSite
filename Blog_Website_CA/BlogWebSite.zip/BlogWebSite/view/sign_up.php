
<link href="http://netdna.bootstrapcdn.com/font-awesome/4.0.3/css/font-awesome.css" rel="stylesheet">
<link href="../css/signup.css" rel="stylesheet" type="text/css"/>
<?php
include ("header.php");
?>

<header class="ccheader">
    <h1>Register To Become A User</h1>	
</header>

<div  class="wrapper">
    <form action="." method="post" class="ccform" id="form" enctype="multipart/form-data">
        <input type="hidden" name="action" value="create_member">   

        <div class="ccfield-prepend">
            <span class="ccform-addon"><i id='firsticon' class="fa fa-user fa-2x"></i></span>
            <input name="first-name" id ="fname" class="ccformfield" type="text" placeholder="First Name" required>
        </div>
        <div class="ccfield-prepend">
            <span class="ccform-addon"><i class="fa fa-user fa-2x"></i></span>
            <input name="last-name" id ="lname" class="ccformfield" type="text" placeholder="Last Name" required>
        </div>
        <div class="ccfield-prepend">
            <span class="ccform-addon"><i class="fa fa-envelope fa-2x"></i></span>
            <input name="email" id ="email" class="ccformfield" type="email" placeholder="Email">
        </div> 
        <div class="ccfield-prepend">
            <span class="ccform-addon"><i class="fa fa-user fa-2x"></i></span>
            <input name="username" id ="username" class="ccformfield" type="text" placeholder="Username" required>
        </div>
        <div class="ccfield-prepend">
            <span class="ccform-addon"><i class="fa fa-star fa-2x"></i></span>
            <input name="password" id ="password"  class="ccformfield" type="password" placeholder="Password" required>
        </div>
        <div class="ccfield-prepend">
            <span class="ccform-addon"><i class="fa fa-calendar fa-2x"></i></span>
            <input name="date" id ="dob" class="ccformfield" type="date" placeholder="Date Of Birth" required>
        </div>

        <div class="ccfield-prepend">
            <span class="ccform-addon"><i class="fa fa-picture fa-2x"></i></span>
            <h3>Please choose a profile picture.</h3>
            <br>
            <input type="file" name="fileToUpload" id="file">
        </div>

        <div class="ccfield-prepend">
            <input class="ccbtn" type="submit" id="submit" value="Sign Up">
        </div>
    </form>
</div>


</body>
</html>
